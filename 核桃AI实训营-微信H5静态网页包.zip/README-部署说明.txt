# 核桃编程 AI 实训营 · 微信 H5 静态网页包

包含 3 个文件：

- `index.html`：微信入口页
- `parent-guide.html`：家长 AI 通识手册
- `student-quiz.html`：学员 AI 闯关小测试

## 本地离线打开

双击 `index.html` 即可在电脑浏览器里打开。三个 HTML 都是单文件静态页面，不依赖外部图片、字体或脚本。

## 微信上直接打开

微信不能稳定打开本地 HTML 文件。需要把这 3 个 HTML 上传到支持 HTTPS 的静态托管服务，然后把 `https://.../index.html` 链接发到微信。

推荐方式：

1. Netlify：登录后把整个文件夹拖到 Sites 页面，即可生成 HTTPS 地址。
2. Vercel：新建项目并上传文件夹，部署后获得 HTTPS 地址。
3. GitHub Pages：把 3 个 HTML 放进仓库根目录，开启 Pages。
4. 公司/机构官网服务器：上传到同一个目录即可。

## 注意

不要只上传 `index.html`，否则按钮跳转不到手册和测试页。
